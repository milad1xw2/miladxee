'use strict';

function empty(data) {
  if(typeof(data) == 'number' || typeof(data) == 'boolean')
  { 
    return false; 
  }
  if(typeof(data) == 'undefined' || data === null)
  {
    return true; 
  }
  if(typeof(data.length) != 'undefined')
  {
    return data.length == 0;
  }
  var count = 0;
  for(var i in data)
  {
    if(data.hasOwnProperty(i))
    {
      count ++;
    }
  }
  return count == 0;
}

function download(filename, text) {
    var element = document.createElement('a');
    element.setAttribute('href', 'data:text/plain;charset=utf-8,' + encodeURIComponent(text));
    element.setAttribute('download', filename);

    element.style.display = 'none';
    document.body.appendChild(element);

    element.click();

    document.body.removeChild(element);
}

var lines = [];
var local_lines = localStorage.getItem('lines');
if(!empty(local_lines)) {
  lines = JSON.parse(local_lines);
}

$('#text-file').on('change', function() {
  var fileName = $(this).val().split("\\").pop();
  $(this).siblings('.custom-file-label').addClass('selected').html(fileName);
});

$('form').on('submit', function(e) {
  e.preventDefault();
  $('#download').show();
  if(!empty(lines)) {
    var url = lines[0];
    lines.shift();
    localStorage.setItem('lines', JSON.stringify(lines));
    $('.card').show();
    $('.card-body').html('متن با موفقیت کپی شد!<br><br>متن کپی‌شده:<br>' + url);
      window.open('https://www.aparat.com/user/video/user_list/usercat/302300011/userid/' + url);
   } else if(typeof $('#text-file')[0].files[0] !== 'undefined') {
    var fr = new FileReader();
    fr.readAsText($('#text-file')[0].files[0]);
    fr.onload = (function(f) {
      var lines_tmp = fr.result;
      lines_tmp = lines_tmp.split('\n');
      lines_tmp.forEach(function(line) {
        line = line.trim();
        if(!empty(line)) {
          lines.push(line);
        }
      });
      var url = lines[0];
      lines.shift();
      localStorage.setItem('lines', JSON.stringify(lines));
      $('.card').show();
      $('.card-body').html('متن با موفقیت کپی شد!<br><br>متن کپی‌شده:<br>' + url);
      window.location.href =('https://www.aparat.com/user/video/user_list/usercat/302300011/userid/' + url);
    });
  }
});

$('#download').click(function() {
  download('output_' + Math.floor(Date.now() / 1000).toString() + '.txt', lines.join('\n'));
  $('.card').show();
  $('.card-body').html('فایل جدید با موفقیت دانلود شد!');
});

$('#clear').click(function() {
  localStorage.removeItem('lines');
  lines = [];
  $('.card').show();
  $('.card-body').html('حافظه با موفقیت خالی شد!');
});
